from django.contrib import admin
from .models import Helmet

admin.site.register(Helmet)