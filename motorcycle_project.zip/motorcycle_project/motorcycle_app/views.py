from django.shortcuts import render, redirect, get_object_or_404
from .models import Motorcycle
from .forms import MotorcycleForm

def motorcycle_list(request):
    motorcycles = Motorcycle.objects.all()
    return render(request, 'motorcycle_app/motorcycle_list.html', {'motorcycles': motorcycles})

def motorcycle_create(request):
    if request.method == 'POST':
        form = MotorcycleForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('motorcycle_list')
    else:
        form = MotorcycleForm()
    return render(request, 'motorcycle_app/motorcycle_form.html', {'form': form})

def motorcycle_update(request, pk):
    motorcycle = get_object_or_404(Motorcycle, pk=pk)
    if request.method == 'POST':
        form = MotorcycleForm(request.POST, instance=motorcycle)
        if form.is_valid():
            form.save()
            return redirect('motorcycle_list')
    else:
        form = MotorcycleForm(instance=motorcycle)
    return render(request, 'motorcycle_app/motorcycle_form.html', {'form': form})

def motorcycle_delete(request, pk):
    motorcycle = get_object_or_404(Motorcycle, pk=pk)
    if request.method == 'POST':
        motorcycle.delete()
        return redirect('motorcycle_list')
    return render(request, 'motorcycle_app/motorcycle_confirm_delete.html', {'motorcycle': motorcycle})