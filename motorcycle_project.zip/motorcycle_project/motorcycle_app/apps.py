from django.apps import AppConfig


class MotorcycleAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'motorcycle_app'
