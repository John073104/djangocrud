
from django.urls import path
from .views import motorcycle_list, motorcycle_create, motorcycle_update, motorcycle_delete

urlpatterns = [
    path('', motorcycle_list, name='motorcycle_list'),
    path('motorcycle/new/', motorcycle_create, name='motorcycle_create'),
    path('motorcycle/<int:pk>/edit/', motorcycle_update, name='motorcycle_update'),
    path('motorcycle/<int:pk>/delete/', motorcycle_delete, name='motorcycle_delete'),
]