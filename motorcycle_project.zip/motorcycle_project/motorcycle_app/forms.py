
from django import forms
from .models import Motorcycle

class MotorcycleForm(forms.ModelForm):
    class Meta:
        model = Motorcycle
        fields = ['brand', 'engine_displacement', 'transmission', 'color', 'performance']

    def clean_brand(self):
        brand = self.cleaned_data.get('brand')
        if any(char.isdigit() for char in brand):
            raise forms.ValidationError("Brand must not contain numbers.")
        if not brand.isalpha():
            raise forms.ValidationError("Brand must contain only letters.")
        return brand

    def clean_engine_displacement(self):
        engine_displacement = self.cleaned_data.get('engine_displacement')
        if engine_displacement is None or not isinstance(engine_displacement, int):
            raise forms.ValidationError("Engine Displacement must be a valid number.")
        return engine_displacement