from django.db import models

class Motorcycle(models.Model):
    brand = models.CharField(max_length=100)
    engine_displacement = models.PositiveIntegerField()
    transmission = models.CharField(max_length=50)
    color = models.CharField(max_length=30)
    performance = models.CharField(max_length=50)

    def __str__(self):
        return self.brand