from django.contrib import admin
from .models import MLBBPlayer

admin.site.register(MLBBPlayer)