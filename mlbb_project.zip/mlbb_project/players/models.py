from django.db import models

class MLBBPlayer(models.Model):
    player_name = models.CharField(max_length=100)
    rank = models.CharField(max_length=50)
    main_hero = models.CharField(max_length=100)
    best_role = models.CharField(max_length=50)
    total_matches_played = models.IntegerField()

    def __str__(self):
        return self.player_name